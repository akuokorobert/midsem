<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  
  <table border="1">
<tr>
  <th>GROUP A</th>
  <th>GROUP B</th>
  <th>GROUP C</th>
</tr>

<tr>
  <td>Ghana</td>
  <td>Brazil</td>
  <td>Argentina</td>
</tr>



  <td>Portugal</td>
  <td>England</td>
  <td>France</td>
</tr>


<td>Canada</td>
  <td>Switzerland</td>
  <td>USA</td>
</tr>



<td>uruguay</td>
  <td>Senegal</td>
  <td>Cameroon</td>
</tr>





  </table>
  
</body>
</html>
