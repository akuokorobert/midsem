<html>


<head>



<img src="./gamebacko.png" alt="An image" width="100px">


<ul>
    <li>AKUOKO ROBERT BASOAH</li>
    <li>0547127325</li>
    <li>akuokorobert887@gmail.com</li>
    <li>BSc IT</li>
    <li>L300</li>
    <li>UEB3254522</li>
</ul>



</body>

<footer>



</footer>





























</html>